﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Publication
    {
        public String title { get; set; }
        public float price { get; set; }

        public Publication(String title, float price)
        {
            this.title = title;
            this.price = price;
        }

        public override string ToString()
        {
            return $"Title of book is {title} and price is {price}";
        }

        class Book : Publication
        {
            int count { get; set; }
            String author { get; set; }
            public Book(String title,float price,int count,String author) : base(title,price)
            {
                this.count = count;
                this.author = author;
            }
            public override string ToString()
            {
                return $@"The author of the book is {author} and the no. of pages are {count}";
            }
        }
        
        class Video: Publication
        {
            float video_duration { get; set; }
            public Video(String title,float price,float video_duration) : base(title,price)
            {
                this.video_duration = video_duration;
            }
            public override string ToString()
            {
                return $@"The video duaration is {video_duration}";
            }
        }
    }
    public class display_publication
    {
        static void Main(string[] args)
        {
            String title;
            float price;
            Console.WriteLine("Enter the title");
            title = Console.ReadLine();
            Console.WriteLine("Enter the price");
            price = int.Parse(Console.ReadLine());

            Publication p = new Publication(title, price);
            Console.WriteLine(p.ToString());

            Console.WriteLine("Enter author name");
            String author = Console.ReadLine();
            Console.WriteLine("Enter the Page count");
            int count = int.Parse(Console.ReadLine());

            Book b = new Book(title, price, author, count);
            Console.WriteLine(b.ToString());

            Console.WriteLine("Enter the video duration");
            float video_duration = int.Parse(Console.ReadLine());

            Video v = new Video(title, price, video_duration);
            Console.WriteLine(v.ToString());

        }
    }

    class Book
    {
        private string title;
        private float price;
        private string author;
        private int count;

        public Book(string title, float price, string author, int count)
        {
            this.title = title;
            this.price = price;
            this.author = author;
            this.count = count;
        }
    }

    internal class Video
    {
        private string title;
        private float price;
        private float video_duration;

        public Video(string title, float price, float video_duration)
        {
            this.title = title;
            this.price = price;
            this.video_duration = video_duration;
        }
    }
}
