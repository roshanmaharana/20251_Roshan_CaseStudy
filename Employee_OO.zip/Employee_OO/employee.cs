﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_OO
{
    /// <summary>
    /// Abstract Class Declaration and Definition of Employee type
    /// with the relevant attributes and behaviour
    /// </summary>
    public abstract class Employee
    {
        public string EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeAddress { get; set; }
        public double EmployeeBasicPay { get; set; }

        public Employee(string EmployeeID, string EmployeeName, string EmployeeAddress, double EmployeeBasicPay)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeBasicPay = EmployeeBasicPay;
        }

        public override string ToString()
        {
            return $"Employee Name is {EmployeeName} and ID is {EmployeeID}";
        }
        public abstract double calculateSalary(double hra,double salary); //
    }
    
}
