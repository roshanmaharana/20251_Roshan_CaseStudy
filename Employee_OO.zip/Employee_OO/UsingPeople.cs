﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_OO
{
    /// <summary>
    /// Instances of Abstract Employee class 
    /// and the derived classes
    /// TechnicalEmployee and Staff classes
    /// with their respective methods and attributes
    /// </summary>
    class UsingPeople
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Employee ID");
            String EmployeeID = Console.ReadLine();
            Console.WriteLine("Enter Employee Name");
            String EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter Employee Address");
            String EmployeeAddress = Console.ReadLine();
            Console.WriteLine("Enter Employee Basic salary");
            double basic_salary = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Basic salary");
            double hra = double.Parse(Console.ReadLine());
            Employee emp;

            Console.WriteLine("Enter (T/t) for Technical Employee or (S/s) for Staff");
            char designation = char.Parse(Console.ReadLine());

            if (designation == 't' || designation == 'T')
            {
                Console.WriteLine("Enter Technical Skill");
                string TechnicalSkill = Console.ReadLine();
                emp = new TechnicalEmployee(EmployeeID, EmployeeName, EmployeeAddress, basic_salary, TechnicalSkill);
                var salary = emp.calculateSalary(hra, basic_salary);
                Console.WriteLine("The Employee ID is {0}", emp.EmployeeID);
                Console.WriteLine("The Employee Name is {0}", emp.EmployeeName);
                Console.WriteLine("The Employee Address is {0}", emp.EmployeeAddress);
                Console.WriteLine("The Employee Designation is Technical Employee");
                Console.WriteLine("The Technical Skill is {0}", TechnicalSkill);
                Console.WriteLine("The Employee salary is {0}", salary);
            }

            else if (designation == 's' || designation == 'S')
            {
                Console.WriteLine("Enter Staff Title");
                string StaffTitle = Console.ReadLine();
                emp = new Staff(EmployeeID, EmployeeName, EmployeeAddress, basic_salary, StaffTitle);
                var salary = emp.calculateSalary(hra, basic_salary);
                Console.WriteLine("The Employee ID is {0}", emp.EmployeeID);
                Console.WriteLine("The Employee Name is {0}", emp.EmployeeName);
                Console.WriteLine("The Employee Address is {0}", emp.EmployeeAddress);
                Console.WriteLine("The Employee Designation is Staff");
                Console.WriteLine("The Staff Title is {0}", StaffTitle);
                Console.WriteLine("The Employee salary is {0}", salary);
            }

            else
            {
                Console.WriteLine("Invalid Designation");
            }


        }
    }
}
