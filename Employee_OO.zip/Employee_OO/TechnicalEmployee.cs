﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_OO
{
    /// <summary>
    /// Derived Class from Employee
    /// for the Designation of TechnicalEmployee
    /// </summary>
    public class TechnicalEmployee : Employee
    {
        public string TechnicalSkill { get; set; }
        public TechnicalEmployee(string EmployeeID, string EmployeeName, string EmployeeAddress, double EmployeeBasicPay, string TechnicalSkill) : base(EmployeeID, EmployeeName, EmployeeAddress, EmployeeBasicPay)
        {
            this.TechnicalSkill = TechnicalSkill;
        }

        public override double calculateSalary(double hra, double salary)
        {
            hra = 0.12 * EmployeeBasicPay;
            salary = EmployeeBasicPay + hra;
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return $"Employee Name is {EmployeeName} and ID is {EmployeeID}";
        }
    }

}
