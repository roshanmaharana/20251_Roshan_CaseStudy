﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_OO
{
    public class Staff : Employee
    {
        public string StaffTitle { get; set; }
        public Staff(string EmployeeID, string EmployeeName, string EmployeeAddress, double EmployeeBasicPay, string StaffTitle) : base(EmployeeID, EmployeeName, EmployeeAddress, EmployeeBasicPay)
        {
            this.StaffTitle = StaffTitle;
        }
        public override double calculateSalary(double hra, double salary)
        {
            hra = 0.18 * EmployeeBasicPay;
            salary = EmployeeBasicPay + hra;
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return $"Employee Name is {EmployeeName} and ID is {EmployeeID}";
        }
    }
}
